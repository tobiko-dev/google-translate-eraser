# Google Translate Image Clear

Press the backtick key (`) while using **Google Translate → Images** to clear
the current uploaded image and return to the empty upload/paste screen.

Workflow:

1. Paste an image.
2. Read/copy the translation.
3. Press `.
4. Paste the next image.

The extension first tries Google's own clear/X control. If Google changes the
button or it cannot be found, it falls back to reloading the Images page, which
also clears the uploaded image.

The shortcut does not fire while actively typing inside a text field.

## Edge / Brave

1. Extract the ZIP.
2. Open `edge://extensions` or `brave://extensions`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select this extracted folder.

If you installed the previous version, remove or disable it first.

## Firefox

1. Extract the ZIP.
2. Open `about:debugging#/runtime/this-firefox`.
3. Click **Load Temporary Add-on...**
4. Select `manifest.json`.
